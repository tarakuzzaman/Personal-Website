@extends('frontEnd.master')

@section('title_area')
    Tarakuzzaman Hridoy
@endsection

@section('css_js')
    <link href="{{asset('frontEnd')}}/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('frontEnd')}}/css/style.css">
    <link rel="stylesheet" type="text/css" href="{{asset('frontEnd')}}/css/fontawesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('frontEnd')}}/css/all.min.css">
@endsection


