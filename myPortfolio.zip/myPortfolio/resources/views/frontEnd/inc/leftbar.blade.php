<div class="col-md-3 col-sm-3">
    <div class="row">
        <div class="left_side">
            <div class="col-sm-8">
                <div class="logo_section">
                    <h2>Tareku<span style="color:#fff">ZZ</span>aman</h2>
                    <p>Web Developer</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="menubar_sec">
                    <ul>
                        <li style="background: #1e90ff;"><a href="#">Home</a></li>
                        <li style="background: #AEDB03;"><a href="#">About</a></li>
                        <li style="background: #f9ca24;"><a href="#">Sevices</a></li>
                        <li style="background: #e58e26;"><a href="#">Protfolio</a></li>
                        <li style="background: #AD2FC8;"><a href="#">Support</a></li>
                        <li style="background: #d63031;"><a href="#">Contact</a></li>
                    </ul>

                </div>
            </div>
        </div>
    </div>
</div>