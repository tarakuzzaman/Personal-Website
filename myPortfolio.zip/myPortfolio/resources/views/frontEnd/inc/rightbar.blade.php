<div class="row">
    <div class="right_side">
        <div class="pro_pic">
            <img src="{{asset('frontEnd')}}/img/tarek.png">
        </div>
        <div class="future_pic">
            <h2>Future Works</h2>
            <div class="fu_img">
                <img src="{{asset('frontEnd')}}/img/n1.jpg">
                <img src="{{asset('frontEnd')}}/img/n2.jpg">
            </div>
            <div class="fu_img">
                <img src="{{asset('frontEnd')}}/img/p1.jpg">
                <img src="{{asset('frontEnd')}}/img/p2.jpg">
            </div>
            <div class="fu_img">
                <img src="{{asset('frontEnd')}}/img/n1.jpg">
                <img src="{{asset('frontEnd')}}/img/n2.jpg">
            </div>

        </div>

    </div>
</div>