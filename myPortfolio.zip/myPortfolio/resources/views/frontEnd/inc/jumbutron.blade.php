<div class="body_head">
    <h2>No Standard Design, Only Unique Artistic Works!
    </h2>
    <button>Viwe Protfolio</button>
</div>