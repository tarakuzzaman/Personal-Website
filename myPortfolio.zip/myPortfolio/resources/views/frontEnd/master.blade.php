<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('title_area')</title>
    @yield('css_js')
</head>
<body>

<div class="main">
@include('frontEnd.inc.leftbar')

    <div class="col-md-6 col-sm-6">
        <div class="row">
            <div class="body_content">

                @include('frontEnd.inc.jumbutron')

                <div class="body_blog">
                    <h2>Latest News</h2>
                    <div class="post">
                        <div class="post_cont">
                            <div class="icon">
                                <i class="far fa-calendar-minus"></i>
                            </div>
                            <h4>Lorem Ipsum is simply dummy text of the printing and typesetting </h4>
                            <p>It is a long established fact that a reader will be distracted by the readable content of</p>
                            <h6>10/10/18</h6>
                        </div>
                    </div>

                    <div class="post">
                        <div class="post_cont">
                            <div class="icon">
                                <i class="far fa-calendar-minus"></i>
                            </div>
                            <h4>A simply dummy text of the printing and typesetting </h4>
                            <p>It is a long established fact that a reader will be distracted by the readable content of</p>
                            <h6>10/10/18</h6>
                        </div>
                    </div>

                    <div class="post">
                        <div class="post_cont">
                            <div class="icon">
                                <i class="far fa-calendar-minus"></i>
                            </div>
                            <h4> Text of the printing and typesetting </h4>
                            <p>It is a long established fact that a reader will be distracted by the readable content of</p>
                            <h6>10/10/18</h6>
                        </div>
                    </div>

                    <div class="post">
                        <div class="post_cont">
                            <div class="icon">
                                <i class="far fa-calendar-minus"></i>
                            </div>
                            <h4>Lorem Ipsum is simply dummy text of the printing and typesetting </h4>
                            <p>It is a long established fact that a reader will be distracted by the readable content of</p>
                            <h6>10/10/18</h6>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>


    <div class="col-md-3 col-sm-3">
        @include('frontEnd.inc.rightbar')
    </div>
</div>


<!------- Footer section--------- -->

@include('frontEnd.inc.footer')


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="{{asset('frontEnd')}}/js/bootstrap.min.js"></script>
</body>
</html>