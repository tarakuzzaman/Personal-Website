<div class="row">
    <div class="right_side">
        <div class="pro_pic">
            <img src="<?php echo e(asset('frontEnd')); ?>/img/tarek.png">
        </div>
        <div class="future_pic">
            <h2>Future Works</h2>
            <div class="fu_img">
                <img src="<?php echo e(asset('frontEnd')); ?>/img/n1.jpg">
                <img src="<?php echo e(asset('frontEnd')); ?>/img/n2.jpg">
            </div>
            <div class="fu_img">
                <img src="<?php echo e(asset('frontEnd')); ?>/img/p1.jpg">
                <img src="<?php echo e(asset('frontEnd')); ?>/img/p2.jpg">
            </div>
            <div class="fu_img">
                <img src="<?php echo e(asset('frontEnd')); ?>/img/n1.jpg">
                <img src="<?php echo e(asset('frontEnd')); ?>/img/n2.jpg">
            </div>

        </div>

    </div>
</div><?php /**PATH C:\xampp\htdocs\hridoy\myPortfolio\resources\views/frontEnd/inc/rightbar.blade.php ENDPATH**/ ?>