<?php $__env->startSection('title_area'); ?>
    Tarakuzzaman Hridoy
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_js'); ?>
    <link href="<?php echo e(asset('frontEnd')); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/css/fontawesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontEnd')); ?>/css/all.min.css">
<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hridoy\myPortfolio\resources\views/frontEnd/home/homeContent.blade.php ENDPATH**/ ?>