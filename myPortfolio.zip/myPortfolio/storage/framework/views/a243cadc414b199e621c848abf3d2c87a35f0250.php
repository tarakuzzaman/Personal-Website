<div class="body_head">
    <h2>No Standard Design, Only Unique Artistic Works!
    </h2>
    <button>Viwe Protfolio</button>
</div><?php /**PATH C:\xampp\htdocs\hridoy\myPortfolio\resources\views/frontEnd/inc/jumbutron.blade.php ENDPATH**/ ?>