<div class="footer">
    <div class="container">
        <div class="row">

            <div class="col-lg-6 col-md-6">
                <div class="social">
                    <i class="fab fa-facebook"></i>
                    <i class="fab fa-linkedin"></i>
                    <i class="fab fa-twitter-square"></i>
                    <i class="fab fa-skype"></i>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\hridoy\myPortfolio\resources\views/frontEnd/inc/footer.blade.php ENDPATH**/ ?>